#include "Phobic.h"
#include <utility>
#include <cstdarg>

using namespace std;

Phobic::Phobic(int input){
  numb = input;
  while(is_scary(numb)){
    numb += 1;
  }
}
Phobic::Phobic(const Phobic &rhs){
   numb = rhs.numb;
   fear_num = rhs.fear_num;
}
Phobic &Phobic::operator=(const Phobic &rhs){
  numb = rhs.numb;
  fear_num = rhs.fear_num;
  return *this;
}
Phobic::~Phobic(){
}

// Overloading +,-,*,/ for Object and int returning third object

Phobic operator+(int n, const Phobic &b){
  Phobic phob(b.numb + n);
  for(auto number : b.fear_num){
    phob << number;
  }
  return phob;
}
Phobic operator-(int n, const Phobic &b){
  Phobic phob(n-b.numb);
  for(auto number : b.fear_num){
    phob << number;
  }
  return phob;
}
Phobic operator-(const Phobic &b, int n){
  Phobic phob(b.numb-n);
  for(auto number : b.fear_num){
    phob << number;
  }
  return phob;
}
Phobic operator*(int n, const Phobic &b){
  Phobic phob(b.numb * n);
  for(auto number : b.fear_num){
    phob << number;
  }
  return phob;
}
Phobic operator/(int n, const Phobic &b){
  if(b.numb == 0){
    throw runtime_error("Dividing by zero!");
  }
  Phobic phob(n/b.numb);
  for(auto number : b.fear_num){
    phob << number;
  }
  return phob;
}
Phobic operator/(const Phobic &b, int n){
  if(n == 0){
    throw runtime_error("Dividing by zero!");
  }
  Phobic phob(b.numb/n);
  for(auto number : b.fear_num){
    phob << number;
  }
  return phob;
}

// Overloading the +,-,*,/ operators for two objects creating a third object

Phobic Phobic::operator+(const Phobic& b)const{
  Phobic phob(this->numb + b.numb);
  for(auto fear1: this->fear_num){
    phob<<fear1;
  }
  for(auto fear2: b.fear_num){
    phob<<fear2;
  }
  return phob;
}
Phobic Phobic::operator-(const Phobic& b)const{
  Phobic phob(this->numb - b.numb);
  for(auto fear1: this->fear_num){
    phob<<fear1;
  }
  for(auto fear2: b.fear_num){
    phob<<fear2;
  }
  return phob;
}
Phobic Phobic::operator*(const Phobic& b)const{
  Phobic phob(this->numb * b.numb);
  for(auto fear1: this->fear_num){
    phob<<fear1;
  }
  for(auto fear2: b.fear_num){
    phob<<fear2;
  }
  return phob;
}
Phobic Phobic::operator/(const Phobic& b)const{
  if(b.numb == 0){
    throw runtime_error("Dividing by zero!");
  }
  Phobic phob(this->numb / b.numb);
  for(auto fear1: this->fear_num){
    phob<<fear1;
  }
  for(auto fear2: b.fear_num){
    phob<<fear2;
  }
  return phob;
}

//Overloading << so it insert scary numb to object

Phobic &Phobic::operator<<(int n){
  fear_num.push_back(n);
  while(is_scary(numb)){
    numb += 1;
  }
  return *this;
}

// Overloading +=,-=,*=, /= between two objects

const Phobic &Phobic::operator+=(const Phobic &n){
  numb += n.numb;
  for(auto x:n.fear_num){
    fear_num.push_back(x);
  }
  while(is_scary(numb)){
    numb += 1;
  }
  return *this;
}
const Phobic &Phobic::operator-=(const Phobic &n){
  numb -= n.numb;
  for(auto x:n.fear_num){
    fear_num.push_back(x);
  }
  while(is_scary(numb)){
    numb += 1;
  }
  return *this;
}
const Phobic &Phobic::operator*=(const Phobic &n){
  numb *= n.numb;
  for(auto x:n.fear_num){
    fear_num.push_back(x);
  }
  while(is_scary(numb)){
    numb += 1;
  }
  return *this;
}
const Phobic &Phobic::operator/=(const Phobic &n){
  if(n.numb == 0){
    throw runtime_error("Dividing by zero!");
  }
  numb /= n.numb;
  for(auto x:n.fear_num){
    fear_num.push_back(x);
  }
  while(is_scary(numb)){
    numb += 1;
  }
  return *this;
}

// Overloading ==,!=,<,>,<=,>= between object and int

bool operator==(int n, const Phobic &b){
  return n == b.numb;
}
bool operator!=(int n, const Phobic &b){
  return n != b.numb;
}
bool operator>(int n, const Phobic &b){
  return n > b.numb;
}
bool operator<(int n, const Phobic &b){
  return n < b.numb;
}
bool operator>=(int n, const Phobic &b){
  return n >= b.numb;
}
bool operator<=(int n, const Phobic &b){
  return n <= b.numb;
}

// Overloading ==,!=,<,>,<=,>= between two objects

bool Phobic::operator==(const Phobic &n)const{
    return numb == n.numb;
}
bool Phobic::operator!=(const Phobic &n)const{
    return numb != n.numb;
}
bool Phobic::operator<(const Phobic &n)const{
    return numb < n.numb;
}
bool Phobic::operator>(const Phobic &n)const{
    return numb > n.numb;
}
bool Phobic::operator<=(const Phobic &n)const{
    return numb <= n.numb;
}
bool Phobic::operator>=(const Phobic &n)const{
    return numb >= n.numb;
}

int Phobic::get()const{
  return numb;
}

bool Phobic::is_scary(int n){
  for(int x:fear_num){
    if(x == n){
      return true;
    }
  }
  return false;
}

ostream &operator<<(ostream &os, const Phobic &val) {
  os<<val.numb<< ": \n";
    for(int n: val.fear_num){
      os << n<< ", ";
    }
    os << '\n';
    return os;
}
