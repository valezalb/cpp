#ifndef PHOBIC_H_INCLUDED
#define PHOBIC_H_INCLUDED

#include <iostream>
#include <vector>

class Phobic{
  public:

    Phobic(int input = 0);
    Phobic(const Phobic &);
    Phobic &operator=(const Phobic &rhs);
    ~Phobic();

    Phobic operator+(const Phobic& b)const;
    Phobic operator-(const Phobic& b)const;
    Phobic operator*(const Phobic& b)const;
    Phobic operator/(const Phobic& b)const;

    Phobic &operator<<(int n);

    const Phobic &operator+=(const Phobic &);
    const Phobic &operator-=(const Phobic &);
    const Phobic &operator*=(const Phobic &);
    const Phobic &operator/=(const Phobic &);

    bool operator==(const Phobic &)const;
    bool operator!=(const Phobic &)const;
    bool operator<(const Phobic &)const;
    bool operator>(const Phobic &)const;
    bool operator<=(const Phobic &)const;
    bool operator>=(const Phobic &)const;

    int get()const;

    bool is_scary(int n);

    int numb;
    std::vector<int> fear_num = {13};

};
 Phobic operator+(int n, const Phobic &b);
 Phobic operator-(int n, const Phobic &b);
 Phobic operator-(const Phobic &b, int n);
 Phobic operator*(int n, const Phobic &b);
 Phobic operator/(int n, const Phobic &b);
 Phobic operator/(const Phobic &b, int n);

 bool operator==(int n, const Phobic &b);
 bool operator!=(int n, const Phobic &b);
 bool operator>(int n, const Phobic &b);
 bool operator<(int n, const Phobic &b);
 bool operator>=(int n, const Phobic &b);
 bool operator<=(int n, const Phobic &b);

 std::ostream &operator<<(std::ostream &, const Phobic &);
#endif
