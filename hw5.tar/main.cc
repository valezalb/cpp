#include <iostream>
#include <bits/stdc++.h>
#include <unistd.h>
using namespace std;

void normalPrint(int size, int count[],int inCount, int left){
  int countout = 0;
  for(int j=0;j<size+1;j++){
    if(count[j] != 0){
      cout<<j+left << "x"<<count[j]<<" ";
    }
  }
  cout<<"\n";
  for(int h=0;h<size+1;h++){
    while(count[h] != 0){
      if(countout == (inCount-1)){
        cout<<h+left<<"\n";
        break;
      }
      cout<< h+left<<",";
      count[h]--;
      countout++;
    }
  }
}


void cnormalPrint(int size, int count[],int inCount,string str, int left){
  int countout = 0;
  for(int j=0;j<size+1;j++){
    if(count[j] != 0){
      cout<<j+left <<"x"<<count[j]<<" ";
    }
  }
  cout<<"\n";
  for(int h=0;h<size+1;h++){
    while(count[h] != 0){
      if(countout == (inCount-1)){
        cout<<h+left<<"\n";
        break;
      }
      cout<< h+left<<str;
      count[h]--;
      countout++;
    }
  }
}

void fPrint(int size, int count[], int left){
  for(int j=0;j<size+1;j++){
    if(count[j] != 0){
      cout<<j+left << "x"<<count[j]<<" ";
    }
  }
  cout<<"\n";
}

void csPrint(int size, int count[],string str,int left,int inCount){
  int countout=0;
  for(int h=0;h<size+1;h++){
    while(count[h] != 0){
      if(countout == (inCount-1)){
        cout<<h+left<<"\n";
        break;
      }
      cout<< h+left<<str;
      count[h]--;
      countout++;
    }
  }
}

void sPrint(int size, int count[],int inCount, int left){
  int countout=0;
  for(int h=0;h<size+1;h++){
    while(count[h] != 0){
      if(countout == (inCount-1)){
        cout<<h+left<<"\n";
        break;
      }
      cout<< h+left<<",";
      count[h]--;
      countout++;
    }
  }
}

int main (int argc,char *argv[]){
  bool v=false,s=false,c=false,f=false,r=false;
  int leftBound=0,rightBound=99,opt;
  string str,sup,delimiter = "-";
  while (( opt = getopt(argc, argv, "vsfc:r:")) != -1) {
    switch (opt) {
    case 'v':
        v = true;
        break;
    case 's':
        s = true;
        break;
    case 'f':
        f = true;
        break;
    case 'c':
        c = true;
        str = optarg;
        break;
    case 'r':
        r=true;
        sup = optarg;
        break;
    default: /* '?' */
        v=false;s=false;f=false,c=false,r=false;
        return 0;
    }
  }
  if(r){
      string leftB=sup.substr(0,sup.find(delimiter));
      if(leftB.empty()){
        cerr << "No lower bound given: "<< argv[0]<<'\n';
      }
      stringstream degree(leftB);
      degree >> leftBound;
      sup.erase(0,sup.find(delimiter) + delimiter.length());
      string rightB=sup;
      if(rightB.empty()){
        cerr << "No upper Bound given: "<< argv[0]<<'\n';
      }
      stringstream magnitude(rightB);
      magnitude >> rightBound;
   }
   if(leftBound > rightBound){
     cerr <<"Upper Range lower than lower range: "<< argv[0];
   }
   int left=leftBound,right=rightBound,size=right-left,inCount=0,digit;
   int *count{ new int[size]{} };
   if(optind != argc){
     for(int i=optind; i<argc;i++){
       ifstream in(argv[i]);
       if(!in.is_open()){
           cerr << "Couldn't open: "<<argv[i]<<'\n';
           return EXIT_FAILURE;
         }
       if(v){
         cout << "Reading from "<<argv[i]<<'\n';
       }
       while(in >> digit){
         if(digit >= left && digit <= right){
           count[digit-left] += 1;
           inCount++;
         }
       }
     }
     if(s && !f){
       if(c){
         csPrint(size,count,str,left,inCount);
       }
       sPrint(size,count,inCount,left);
     }
     else if (f && !s){
        fPrint(size,count,left);
     }
     else{
       if(c){
         cnormalPrint(size,count,inCount,str,left);
       }
       else{
         normalPrint(size,count,inCount,left);
       }
     }
     delete []count;
   }
   else{
     while(cin >> digit){
       if(digit >= left && digit <= right){
         count[digit-left] += 1;
         inCount++;
       }
     }
     if(s && !f){
       if(c){
         csPrint(size,count,str,left,inCount);
       }
       sPrint(size,count,inCount,left);
     }
     else if (f && !s){
        fPrint(size,count,left);
     }
     else{
       if(!c){
         normalPrint(size,count,inCount,left);
       }
       else{
         cnormalPrint(size,count,inCount,str,left);
       }
     }
     delete []count;
   }
}
